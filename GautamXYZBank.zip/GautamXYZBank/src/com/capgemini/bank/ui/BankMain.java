package com.capgemini.bank.ui;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bank.bean.BankBean;
import com.capgemini.bank.exception.BankException;
import com.capgemini.bank.service.BankServiceImpl;
import com.capgemini.bank.service.IBankService;


public class BankMain {

	static Scanner sc = new Scanner(System.in);
	static IBankService bankService = null;
	static BankServiceImpl bankServiceImpl = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources//log4j.properties");
		BankBean bankBean = null;

		String bankId = null;
		int option = 0;

		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("   ICARE CAPGEMINI TRUST ");
			System.out.println("_______________________________\n");

			System.out.println("1.Enter Demand Draft Details ");
			System.out.println("2.Print Demand Draft");
			System.out.println("3.Retrive All");
			System.out.println("4.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:

					while (bankBean == null) {
						bankBean = populateBankBean();
						// System.out.println(bankBean);
					}

					try {
						bankService = new BankServiceImpl();
						bankId = bankService.addBankDetails(bankBean);

						System.out
								.println("Demand-Draft Details has been successfully registered ");
						System.out.println("Demand-Draft No Is: " + bankId);

					} catch (BankException bankException) {
						logger.error("exception occured", bankException);
						System.out.println("ERROR : "
								+ bankException.getMessage());
					} finally {
						bankId = null;
						bankService = null;
						bankBean = null;
					}

					break;

				case 2:

					bankServiceImpl = new BankServiceImpl();

					System.out.println("Enter numeric bank id:");
					bankId = sc.next();

					while (true) {
						if (bankServiceImpl.validateBankId(bankId)) {
							break;
						} else {
							System.err
									.println("Please enter numeric bank id only, try again");
							bankId = sc.next();
						}
					}

					bankBean = getBankDetails(bankId);

					if (bankBean != null) {
						System.out.println("Customer Name             :"
								+ bankBean.getCustomerName());
						System.out.println("DD-Amount          :"
								+ bankBean.getDdAmount());
						System.out.println("In Favour OF       :"
								+ bankBean.getInFavourOf());
						System.out.println("Phone Number     :"
								+ bankBean.getPhoneNumber());
						System.out.println("DD-Commission          :"
								+ bankBean.getDdCommission());
						System.out.println("DD-Description       :"
								+ bankBean.getDdDescription());
						System.out.println("Date-OF-Transaction  :"
								+ bankBean.getDateOfTransaction());
						
						
						
					
						
						
						
						
						
						
						
						
					} else {
						System.err
								.println("There are no Demand-Draft details associated with bank id "
										+ bankId);
					}

					break;

				case 3:

					bankService = new BankServiceImpl();
					try {
						List<BankBean> bankList = new ArrayList<BankBean>();
						bankList = bankService.retriveAll();

						if (bankList != null) {
							Iterator<BankBean> i = bankList.iterator();
							while (i.hasNext()) {
								System.out.println(i.next());
							}
						} else {
							System.out
									.println("No Demand-Draft, yet.");
						}

					}

					catch (BankException e) {

						System.out.println("Error  :" + e.getMessage());
					}

					break;

				case 4:

					System.out.print("Exit Trust Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}

		}// end of while
	}// end of try

	/*
	 * This function will call the service layer method and return the bean
	 * object which is populated by the information of the given bankId in
	 * parameter
	 */
	private static BankBean getBankDetails(String bankId) {
		BankBean bankBean = null;
		bankService = new BankServiceImpl();

		try {
			bankBean = bankService.viewBankDetails(bankId);
		} catch (BankException bankException) {
			logger.error("exception occured ", bankException);
			System.out.println("ERROR : " + bankException.getMessage());
		}

		bankService = null;
		return bankBean;
	}

	/*
	 * This function will be called by main and will return a validated bean
	 * object OR null if details are invalid
	 */
	private static BankBean populateBankBean() {

		// Reading and setting the values for the bankBean
		
		BankBean bankBean = new BankBean();;

		System.out.println("\n Enter Details");

		System.out.println("Enter bank name: ");
		bankBean.setCustomerName(sc.next());

		System.out.println("Enter amount: ");
		bankBean.setDdAmount(sc.next());

		System.out.println("Enter In Favour OF: ");
		bankBean.setInFavourOf(sc.next());

	
		System.out.println("Enter PhoneNumber: ");
		bankBean.setPhoneNumber(sc.next());

		System.out.println("Enter DD-Commission: ");
		bankBean.setDdCommission(sc.next());

		System.out.println("Enter DD-Description: ");
		bankBean.setDdDescription(sc.next());

		System.out.println("Enter Date Of Transaction: ");
		bankBean.setDateOfTransaction(sc.next());

		
		
		
		
		
		
	
		
		
		
		
		
		
		
		
		
		
		bankServiceImpl = new BankServiceImpl();
		
		

		/*try {
			bankBean.setDdAmount(sc.next());
		} catch (InputMismatchException inputMismatchException) {
			sc.nextLine();
			System.err
					.println("Please enter a numeric value for  amount, try again");
			}

		bankServiceImpl = new BankServiceImpl();

		try {
			bankServiceImpl.validateBank(bankBean);
			return bankBean;
		} catch (BankException bankException) {
			logger.error("exception occured", bankException);
			System.err.println("Invalid data:");
			System.err.println(bankException.getMessage() + " \n Try again..");
			System.exit(0);

		}*/
		return bankBean;

	}
}
