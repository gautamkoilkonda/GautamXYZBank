package com.capgemini.bank.dao;

public interface QueryMapper {
	
	public static final String RETRIVE_ALL_QUERY="SELECT transaction_id,customer_name,in_favor_of,phone_number,date_of_transaction,dd_amount,dd_commission,dd_description FROM demand_draft";
	public static final String VIEW_BANK_DETAILS_QUERY="SELECT customer_name,in_favor_of,phone_number,date_of_transaction,dd_amount,dd_commission,dd_description FROM demand_draft WHERE  transaction_id=?";
	public static final String INSERT_QUERY="INSERT INTO demant_draft VALUES(Transaction_Id_Seq.NEXTVAL,?,?,?,?,?,?,?)";
	public static final String BANKID_QUERY_SEQUENCE="SELECT Transaction_Id_Seq.CURRVAL FROM DUAL";
	
	
}
