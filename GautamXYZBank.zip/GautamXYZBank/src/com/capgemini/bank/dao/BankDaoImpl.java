package com.capgemini.bank.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bank.bean.BankBean;
import com.capgemini.bank.exception.BankException;
import com.capgemini.bank.util.DBConnection;


public class BankDaoImpl implements IBankDAO 
{
	
	Logger logger=Logger.getRootLogger();
	public BankDaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	

	//------------------------ 1. Bank Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addBankDetails(BankBean bank)
	 - Input Parameters	:	BankBean bank
	 - Return Type		:	String
	 - Throws			:  	BankException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	18/11/2016
	 - Description		:	Adding Bank
	 ********************************************************************************************************/

	public String addBankDetails(BankBean bank) throws BankException 
	{
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String bankId=null;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			preparedStatement.setString(1,bank.getCustomerName());			
			preparedStatement.setString(2,bank.getDdAmount());
			preparedStatement.setString(3,bank.getInFavourOf());
			preparedStatement.setString(4,bank.getPhoneNumber());
			preparedStatement.setString(5,bank.getDdCommission());
			preparedStatement.setString(6,bank.getDdDescription());
			preparedStatement.setString(7,bank.getDateOfTransaction());
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.BANKID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				bankId=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new BankException("Inserting bank details failed ");

			}
			else
			{
				logger.info("Bank details added successfully:");
				return bankId;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new BankException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new BankException("Error in closing db connection");

			}
		}
		
		
	}

	//------------------------ 1. Bank Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	viewBankDetails(String bankId)
	 - Input Parameters	:	bankId
	 - Return Type		:	BankBean
	 - Throws			:  	BankException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	18/11/2016
	 - Description		:	ViewBankDetails
	 ********************************************************************************************************/
	public BankBean viewBankDetails(String bankId) throws BankException {
		
		Connection connection=DBConnection.getInstance().getConnection();
		
		
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		BankBean bean=null;
		
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_BANK_DETAILS_QUERY);
			preparedStatement.setString(1,bankId);
			resultset=preparedStatement.executeQuery();
			
			if(resultset.next())
			{
				bean = new BankBean();
				bean.setCustomerName(resultset.getString(1));
				bean.setDdAmount(resultset.getString(2));
				bean.setInFavourOf(resultset.getString(3));
				bean.setPhoneNumber(resultset.getString(4));
				bean.setDdCommission(resultset.getString(5));
				bean.setDdDescription(resultset.getString(6));
				bean.setDateOfTransaction(resultset.getString(7));
			}
			
			if( bean != null)
			{
				logger.info("Record Found Successfully");
				return bean;
			}
			else
			{
				logger.info("Record Not Found Successfully");
				return null;
			}
			
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
			throw new BankException(e.getMessage());
		}
		finally
		{
			try 
			{
				resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new BankException("Error in closing db connection");

			}
		}
		
	}

	//------------------------ 1. Bank Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	retriveAllDetails()
	 - Input Parameters	:	
	 - Return Type		:	List
	 - Throws		    :  	BankException
	 - Author	     	:	CAPGEMINI
	 - Creation Date	:	18/11/2016
	 - Description		:	return list
	 ********************************************************************************************************/

	public List<BankBean> retriveAllDetails() throws BankException {
		
		Connection con=DBConnection.getInstance().getConnection();
		int bankCount = 0;
		
		PreparedStatement ps=null;
		ResultSet resultset = null;
		
		List<BankBean> bankList=new ArrayList<BankBean>();
		try
		{
			ps=con.prepareStatement(QueryMapper.RETRIVE_ALL_QUERY);
			resultset=ps.executeQuery();
			
			while(resultset.next())
			{	
				BankBean bean=new BankBean();
				bean.setCustomerName(resultset.getString(1));
				bean.setDdAmount(resultset.getString(2));
				bean.setInFavourOf(resultset.getString(3));
				bean.setPhoneNumber(resultset.getString(4));
				
				bean.setDdCommission(resultset.getString(5));
				bean.setDdDescription(resultset.getString(6));
				bean.setDateOfTransaction(resultset.getString(7));
				bankList.add(bean);				
				bankCount++;
			}			
			
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new BankException("Tehnical problem occured. Refer log");
		}
		
		finally
		{
			try 
			{
				resultset.close();
				ps.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new BankException("Error in closing db connection");

			}
		}
		
		if( bankCount == 0)
			return null;
		else
			return bankList;
	}

}
