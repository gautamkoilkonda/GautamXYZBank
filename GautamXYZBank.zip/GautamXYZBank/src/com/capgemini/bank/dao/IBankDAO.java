package com.capgemini.bank.dao;

import java.util.List;

import com.capgemini.bank.bean.BankBean;
import com.capgemini.bank.exception.BankException;



public interface IBankDAO 
{
	public String addBankDetails(BankBean bank) throws BankException;
	public BankBean viewBankDetails(String transactionId) throws BankException;
	public List<BankBean> retriveAllDetails()throws BankException;
}
