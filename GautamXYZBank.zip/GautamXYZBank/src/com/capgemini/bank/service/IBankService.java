package com.capgemini.bank.service;

import java.util.List;

import com.capgemini.bank.bean.BankBean;
import com.capgemini.bank.exception.BankException;

public interface IBankService 
{
	public String addBankDetails(BankBean bank) throws BankException;
	public BankBean viewBankDetails(String transactionId) throws BankException;
	public List<BankBean> retriveAll()throws BankException;
}
