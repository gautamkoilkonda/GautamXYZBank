package com.capgemini.bank.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bank.bean.BankBean;
import com.capgemini.bank.dao.BankDaoImpl;
import com.capgemini.bank.dao.IBankDAO;
import com.capgemini.bank.exception.BankException;

public class BankServiceImpl implements IBankService {
	
	IBankDAO bankDao;
	
	//------------------------ 1. Bank Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addBankDetails
	 - Input Parameters	:	bank object
	 - Return Type		:	String id
	 - Throws			:  	BankException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	11/11/2016
	 - Description		:	adding bank to database calls dao method addBankDetails(bank)
	 ********************************************************************************************************/
	public String addBankDetails(BankBean bank) throws BankException {
		bankDao=new BankDaoImpl();	
		String bankSeq;
		bankSeq= bankDao.addBankDetails(bank);
		return bankSeq; 
	}

	//------------------------ 1. Bank Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	viewBankDetails
	 - Input Parameters	:	String bankId
	 - Return Type		:	bank object
	 - Throws		    :  	BankException
	 - Author		    :	CAPGEMINI
	 - Creation Date	:	18/11/2016
	 - Description		:	calls dao method viewBankDetails(bankId)
	 ********************************************************************************************************/
	public BankBean viewBankDetails(String bankId) throws BankException {
		bankDao=new BankDaoImpl();
		BankBean bean=null;
		bean=bankDao.viewBankDetails(bankId);
		return bean;
	}

	//------------------------ 1. Bank Application --------------------------
	/*******************************************************************************************************
	 - Function Name	: retriveAll()
	 - Input Parameters	:	
	 - Return Type		: list
	 - Throws		    : BankException
	 - Author	      	: CAPGEMINI 
	 - Creation Date	: 18/11/2016
	 - Description		: calls dao method retriveAllDetails()
	 ********************************************************************************************************/
	public List<BankBean> retriveAll() throws BankException {
		bankDao=new BankDaoImpl();
		List<BankBean> bankList=null;
		bankList=bankDao.retriveAllDetails();
		return bankList;
	}
	
	
	/*******************************************************************************************************
	 - Function Name	: validateBank(BankBean bean)
	 - Input Parameters	: BankBean bean
	 - Return Type		: void
	 - Throws		    : BankException
	 - Author	      	: CAPGEMINI
	 - Creation Date	: 18/11/2016
	 - Description		: validates the BankBean object
	 ********************************************************************************************************/
	public void validateBank(BankBean bean) throws BankException
	{
		List<String> validationErrors = new ArrayList<String>();

		//Validating bank name
		if(!(isValidName(bean.getCustomerName()))) {
			validationErrors.add("\n Donar Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		//Validating address
		if(!(isValidAddress(bean.getInFavourOf()))){
			validationErrors.add("\n Address Should Be Greater Than 5 Characters \n");
		}
		//Validating Phone Number
		if(!(isValidPhoneNumber(bean.getPhoneNumber()))){
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
		}
		//Validating Donation Amount
		if(!(isValidAmount(bean.getDdAmount()))){
			validationErrors.add("\n Amount Should be a positive Number \n" );
		}
	
		if(!validationErrors.isEmpty())
			throw new BankException(validationErrors +"");
	}

	public boolean isValidName(String bankName){
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(bankName);
		return nameMatcher.matches();
	}
	public boolean isValidAddress(String address){
		return (address.length() > 6);
	}
	
	public boolean isValidPhoneNumber(String phoneNumber){
		Pattern phonePattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(phoneNumber);
		return phoneMatcher.matches();
		
	}
	public boolean isValidAmount(String amount){
		return true;
	}
	public boolean validateBankId(String bankId) {
		
		Pattern idPattern = Pattern.compile("[0-9]{1,4}");
		Matcher idMatcher = idPattern.matcher(bankId);
		
		if(idMatcher.matches())
			return true;
		else
			return false;		
	}
}

	
	


