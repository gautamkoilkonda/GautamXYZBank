package com.capgemini.bank.bean;

import java.util.Date;


public class BankBean 
{
	private String transactionId;
	private String customerName;
	private String phoneNumber;
	private String inFavourOf;
	private String ddAmount;
	private String ddCommission;
	private String ddDescription;
	private String   dateOfTransaction;
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getInFavourOf() {
		return inFavourOf;
	}
	public void setInFavourOf(String inFavourOf) {
		this.inFavourOf = inFavourOf;
	}
	public String getDdAmount() {
		return ddAmount;
	}
	public void setDdAmount(String ddAmount) {
		this.ddAmount = ddAmount;
	}
	public String getDdCommission() {
		return ddCommission;
	}
	public void setDdCommission(String ddCommission) {
		this.ddCommission = ddCommission;
	}
	public String getDdDescription() {
		return ddDescription;
	}
	public void setDdDescription(String ddDescription) {
		this.ddDescription = ddDescription;
	}
	public String getDateOfTransaction() {
		return dateOfTransaction;
	}
	public void setDateOfTransaction(String dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}
	@Override
	public String toString() {
		return "DonorBean [transactionId=" + transactionId + ", customerName=" + customerName + ", phoneNumber="
				+ phoneNumber + ", inFavourOf=" + inFavourOf + ", ddAmount=" + ddAmount + ", ddCommission="
				+ ddCommission + ", ddDescription=" + ddDescription + ", dateOfTransaction=" + dateOfTransaction + "]";
	}
	


}


